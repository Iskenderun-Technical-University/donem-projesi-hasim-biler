# DepoTakipOtomasyonu
C# diliyle yapılmış access veritabanı kullanılmış basit depo takip otomasyonudur.
İlk yaptığım 2015 yıllarındaki projelerimdendir. Oldukça basittir ve bugları mevcuttur.
Hatıra olması bakımından yüklüyorum.

Videosu :
https://www.youtube.com/watch?v=W8VuATd60tA
